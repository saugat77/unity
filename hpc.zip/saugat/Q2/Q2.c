
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <crypt.h>

pthread_mutex_t jam;
int array_alphabets[26] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};

struct value
{
    int start_count;
    int stop_count;
    char *password;
};

void use(char *final, char *source, int start, int end)
{
    memcpy(final, source + start, end);
    *(final + end) = '\0';
}

void *pass_crack(void *args)
{
    struct value *value = (struct value *)args;
    char salt[7];
    char rawPass[7];
    char *show_password;

    use(salt, value->password, 0, 6);
    for (int a = array_alphabets[value->start_count]; a < array_alphabets[value->stop_count]; a++)
    {
        for (int b = 'A'; b <= 'Z'; b++)
        {
            for (int c = 0; c <= 9; c++)
            {
                for(int d=0; d<=9;d++){
                    pthread_mutex_lock(&jam);
                    sprintf(rawPass, "%c%c%d%d", a, b, c, d);
                    show_password = (char *)crypt(rawPass, salt);
                    if (strcmp(value->password, show_password) == 0)
                    {
                        printf("\nEncrypted password: %s\n", show_password);
                        printf("\nDecrypted password: %s\n", rawPass);
                        pthread_mutex_unlock(&jam);
                        _Exit(0);
                    }
                    else
                    {
                        printf("%s %s\n", rawPass, show_password);
                    }
                    pthread_mutex_unlock(&jam);
                }
                
            }
        }
    }
}

void main()
{
    int threadNumber;
    //Insert encrypted password here by running EncryptSHA512.c file.
    char *encrypt_jpass = "$6$AS$g3axXi9gy0jcDkQYED31J6dojLidAzdTtatDiyI7MEO2RTynW/1K7/EZqTiQ39UdXvkgHO93fU8CYBfMTtdBp."; 
    printf("Enter number of threads to use: \n");
    scanf("%d", &threadNumber);
    int count_Alphabets = 26;
    int rem = count_Alphabets % threadNumber;
    int threadSlice[threadNumber];
    for (int l = 0; l < threadNumber; l++)

    {

        threadSlice[l] = count_Alphabets / threadNumber;
    }
    for (int l = 0; l < rem; l++)

    {

        threadSlice[l] = threadSlice[l] + 1;
    }

    int start_thread[threadNumber];
    int end_thread[threadNumber];

    for (int l = 0; l < threadNumber; l++)
    {

        if (l == 0)

        {

            start_thread[l] = 0;
        }

        else if (l == threadNumber - 1)

        {

            start_thread[l] = end_thread[l - 1] + 1;

            end_thread[l] = 25;

            break;
        }
        else

        {

            start_thread[l] = end_thread[l - 1] + 1;

        }

        end_thread[l] = start_thread[l] + threadSlice[l] - 1;

    }

    struct value *struct_arr = (struct value *)malloc(threadNumber * sizeof(struct value));
    pthread_t *thread_id = (pthread_t *)malloc(threadNumber * sizeof(pthread_t));

    for (int i = 0; i < threadNumber; i++)

    {

        (struct_arr + i)->start_count = start_thread[i];

        (struct_arr + i)->stop_count = end_thread[i];

        (struct_arr + i)->password = encrypt_jpass;

    }

    pthread_mutex_init(&jam, NULL);

    for (int i = 0; i < threadNumber; i++)

    {

        pthread_create(&thread_id[i], NULL, pass_crack, &struct_arr[i]);
    }

    for (int i = 0; i < threadNumber; i++)

    {

        pthread_join(thread_id[i], NULL);
   }
}
