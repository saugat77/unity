#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include <omp.h>


void multiplication()
{
  int i,j,threadid,h =1, chunk = 5;

  int rows_a, columns_a;

  int rows_b, columns_b;

  double matA[20][20], matB[20][20], matC[20][20];

  double total = 0.0;  //for storing the matrix value


  int num = 0;

  threadid = omp_get_thread_num();  
  

  FILE *file = fopen("SampleMatricesWithErrors3.txt", "r");
  FILE *outFile = fopen("matrixresults2049825.txt", "w");  

  #pragma omp for schedule (static, chunk) 

  for(int h = 0; h<1; h++)

  {

    while(!feof(file))

    {

      fscanf(file, "%d, %d", &rows_a, & columns_a);

      
      for(int i=0;i<rows_a;i++)

      {

        for(int j=0;j< columns_a-1;j++)

        {

          fscanf(file,"%lf,",&matA[i][j]);

        }

        fscanf(file,"%lf\n",&matA[i][j]);

      }

      fscanf(file, "%d, %d", &rows_b, & columns_b);

      for(int i=0;i<rows_b;i++)

      {

        for(int j=0;j<columns_b-1;j++)

        {

          fscanf(file,"%lf,",&matB[i][j]);

        }

        fscanf(file,"%lf\n",&matB[i][j]);
      }
      
      num++;

      if( columns_a != rows_b)

    {
      printf("Matrices can not be multiplied please change the input!\n");

    }
    else
    {
      for(int i=0; i<rows_a; i++){

        for(int j=0; j< columns_b; j++){  

          for(int k=0; k<rows_b; k++){ 

           total += matA[i][k] * matB[k][j];

          }


          matC[i][j] = total;

          total = 0;
          }
        }
    }
    
    fprintf(outFile ,"%d , %d\n", rows_a,  columns_b);

    for(int i=0; i<rows_a; i++){

      fprintf(outFile ,"[");

      for(int j=0; j< columns_b; j++){  


        fprintf(outFile ,"%lf\t", matC[i][j]);

      }
      
      fprintf(outFile ,"]\n");

      }


      fprintf(outFile, "\n");


    }
  }
  
    
  fclose(file);
  fclose(outFile);

  

}

void main(int argc, char **argv)
{
  //TO TAKE USER INPUT FOR THE USER TO TAKE INPUT OF HOW MANY THREADS THEY WANT
  int threads = atoi(argv[1]); 

  #pragma omp parallel num_threads(threads)

  multiplication();

  printf("CONGRATULATION!!!, You can  now see the matrix multiplication result in matrixresults2049825 file.\n\n");
}